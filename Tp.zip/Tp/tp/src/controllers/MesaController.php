<?php

namespace App\Controllers;

use App\Models\Mesa;
use App\Controllers\CuentaController;

class MesaController{
    public function traer($request, $response, $args) { 
        $data = Mesa::where("codigo", $args['codigo'])->first();
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function traerTodos($request, $response, $args) {
        $data = Mesa::all();
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function crear($request, $response, $args) {
        $mesa = new Mesa;
        $mesa->codigo = self::generarCodigoMesa();
        $mesa->estado = "cerrada";
        $intentos = 0;

        while (Mesa::where("codigo", $mesa->codigo)->first() && $intentos < 5) {
            $intentos = $intentos + 1;
            $mesa->codigo = self::generarCodigoMesa();
        }

        if ($intentos == 5) {
            $data = array("Error" => "No se pudo generar el codigo de la mesa");
            $response->getBody()->write(json_encode($data));
    
            return $response->withStatus(500);
        }

        $mesa->save();
        $data = array("codigo de la mesa" => $mesa->codigo);
        $response->getBody()->write(json_encode($data));

        return $response->withStatus(200);
    }

    public function cambiarEstado($request, $response, $args) {
        if (!isset($request->getParsedBody()['estado']) || $request->getParsedBody()['estado'] == "cerrada") {
            $data = array("Error" => "estado incorrecto");
            $response->getBody()->write(json_encode($data));
    
            return $response->withStatus(400);
        }

        if ($request->getParsedBody()['estado'] != "con clientes esperando pedido" &&
            $request->getParsedBody()['estado'] != "con clientes comiendo" &&
            $request->getParsedBody()['estado'] != "con clientes pagando") {
            $data = array("Error" => "estado incorrecto");
            $response->getBody()->write(json_encode($data));
    
            return $response->withStatus(400);
        }

        $mesa = Mesa::where("codigo", $args['codigo'])->first();
        $mesa->estado = $request->getParsedBody()['estado'];
        $data = $mesa->save();
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function cerrar($request, $response, $args) {
        $mesa = Mesa::where("codigo", $args['codigo'])->first();
        $mesa->estado = "cerrada";
        $data = $mesa->save();

        $monto = CuentaController::facturar($args['codigo']);
        $data = array("monto" => $monto);
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public static function generarCodigoMesa(){ 
        $caracteres = "abcdefghijklmnopqrstuvwxyz0123456789";
        return substr(str_shuffle($caracteres), 0, 5); 
    } 
}

?>