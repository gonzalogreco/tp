<?php

namespace App\Controllers;

use App\Models\Encuesta;
use App\Models\Mesa;

class EncuestaController{
    public function traer($request, $response, $args) { 
        $data = Encuesta::find($args['id']);
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function traerTodos($request, $response, $args) {
        $data = Encuesta::all();
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function puntuar($request, $response, $args) {
        if (! (isset($request->getParsedBody()['cometario']) && 
            isset($request->getParsedBody()['puntuacionMozo']) && 
            isset($request->getParsedBody()['puntuacionMesa']) && 
            isset($request->getParsedBody()['puntuacionResto']) && 
            isset($request->getParsedBody()['puntuacionCocinero']))) {

            $data = array("Error" => "faltan parametros");
            $response->getBody()->write(json_encode($data));
    
            return $response->withStatus(400);
        }

        $mesa = Mesa::where("codigo", $args['codigo'])->first();

        if (! $mesa || $mesa->estado != "cerrada") {
            $data = array("Error" => "Mesa incorrecta");
            $response->getBody()->write(json_encode($data));
    
            return $response->withStatus(404);
        }

        $encuesta = new Encuesta;
        $encuesta->mesa = $args['codigo'];
        $encuesta->comentario = $request->getParsedBody()['cometario'];
        $encuesta->puntuacionMozo = $request->getParsedBody()['puntuacionMozo'];
        $encuesta->puntuacionMesa = $request->getParsedBody()['puntuacionMesa'];
        $encuesta->puntuacionResto = $request->getParsedBody()['puntuacionResto'];
        $encuesta->puntuacionCocinero = $request->getParsedBody()['puntuacionCocinero'];
        $encuesta->save();

        $data = array("estado" => "guardado");
        $response->getBody()->write(json_encode($data));

        return $response->withStatus(200);
    }
}

?>