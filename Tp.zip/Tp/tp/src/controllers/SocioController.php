<?php

namespace App\Controllers;

use App\Models\Socio;

class SocioController{
    public function get($request, $response, $args) {
        $data = Socio::find($args['id']);
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }
}

?>