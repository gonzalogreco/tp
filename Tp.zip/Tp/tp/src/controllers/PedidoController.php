<?php

namespace App\Controllers;

use App\Models\Pedido;
use App\Models\Producto;
use App\Models\Mesa;
use \Datetime;

class PedidoController{
    public function traer($request, $response, $args) {
        $data = Pedido::where("codigo", $args['codigo'])->first();
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function traerPendientes($request, $response, $args) {
        $data = Pedido::where("estado", "pendiente")->get();
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function traerTodos($request, $response, $args) {
        $data = Pedido::all();
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function crear($request, $response, $args) {
        date_default_timezone_set("America/Argentina/Buenos_Aires");
        
        if (!(isset($request->getParsedBody()['cantidad']) && 
            isset($request->getParsedBody()['mesa']) &&
            isset($request->getParsedBody()['cliente']) &&
            isset($request->getParsedBody()['producto']))) {
            $data = array("Error" => "Faltan parametros");
            $response->getBody()->write(json_encode($data));

            return $response->withStatus(400);
        }

        $producto = Producto::find($request->getParsedBody()['producto']);

        if (!$producto) {
            $data = array("Error" => "Id de producto inexistente");
            $response->getBody()->write(json_encode($data));

            return $response->withStatus(400);
        }

        if (!Mesa::where("codigo", $request->getParsedBody()['mesa'])->first()){
            $data = array("Error" => "Codigo de mesa incorrecto");
            $response->getBody()->write(json_encode($data));

            return $response->withStatus(400);
        }

        $pedido = new Pedido;
        $pedido->codigo = self::generarCodigoPedido();
        $pedido->cantidad = $request->getParsedBody()['cantidad'];
        $pedido->mesa = $request->getParsedBody()['mesa'];
        $pedido->producto = $request->getParsedBody()['producto'];
        $pedido->cliente = $request->getParsedBody()['cliente'];
        $pedido->total =   (float)$producto->precio *  (float)$pedido->cantidad;
        $pedido->sector = $producto->tipo;
        $pedido->estado = "pendiente";
        $pedido->fecha = date("Y-m-d H:i:s");
        $intentos = 0;

        while (Pedido::where("codigo", $pedido->codigo)->first() && $intentos < 5) {
            $intentos = $intentos + 1;
            $pedido->codigo = self::generarCodigoPedido();
        }

        if ($intentos == 5) {
            $data = array("Error" => "No se pudo generar el codigo del pedido");
            $response->getBody()->write(json_encode($data));
    
            return $response->withStatus(500);
        }

        $pedido->save();
        $data = array("codigo de pedido" => $pedido->codigo);
        $response->getBody()->write(json_encode($data));

        return $response->withStatus(200);
    }

    public function cambiarEstadoEnPreparacion($request, $response, $args) {
        date_default_timezone_set("America/Argentina/Buenos_Aires");
        
        if (!isset($request->getParsedBody()['estimado'])) {
            $data = array("Error" => "Falta estimacion");
            $response->getBody()->write(json_encode($data));

            return $response->withStatus(400);
        }

        $pedido = Pedido::where("codigo", $args['codigo'])->first();
        $pedido->estado = "en preparacion";
        $pedido->estimado = $request->getParsedBody()['estimado'];
        $pedido->save();

        $data = array("estado" => "en preparacion");
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function cambiarEstadoListo($request, $response, $args) {
        date_default_timezone_set("America/Argentina/Buenos_Aires");

        $pedido = Pedido::where("codigo", $args['codigo'])->first();
        $pedido->estado = "listo para servir";
        $pedido->finalizado = date("Y-m-d H:i:s");
        $pedido->save();

        $data = array("estado" => "listo para servir");
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function cancelar($request, $response, $args) {
        $pedido = Pedido::where("codigo", $args['codigo'])->first();
        $pedido->estado = "cancelado";
        $pedido->save();

        $data = array("estado" => "cancelado");
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function tiempoRestante($request, $response, $args) {
        date_default_timezone_set("America/Argentina/Buenos_Aires");

        $pedido = Pedido::where("codigo", $args['codigo'])->first();
        
        if ($pedido->mesa != $args['mesa']) {
            $data = array("error" => "el pedido no coincide con la mesa");
            $response->getBody()->write(json_encode($data));
            
            return $response->withStatus(400);
        }

        if ($pedido->estado == "cancelado") {
            $data = array("error" => "el pedido fue cancelado");
            $response->getBody()->write(json_encode($data));
            
            return $response->withStatus(400);
        }

        if ($pedido->estado == "listo para servir") {
            $data = array("error" => "el pedido ya esta listo");
            $response->getBody()->write(json_encode($data));
            
            return $response->withStatus(400);
        }

        if ($pedido->estado == "pendiente") {
            $data = array("error" => "el pedido aun no fue estimado");
            $response->getBody()->write(json_encode($data));
            
            return $response->withStatus(400);
        }

        $horaActual = new DateTime('now', new \DateTimeZone('America/Argentina/Buenos_Aires'));
        $estimado = new DateTime($pedido->estimado, new \DateTimeZone('America/Argentina/Buenos_Aires'));
        $espera = $estimado->diff($horaActual);
        $data = array("tiempo de espera" => $espera->format('%H:%I:%S'));
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public static function generarCodigoPedido(){ 
        $caracteres = "abcdefghijklmnopqrstuvwxyz0123456789";
        return substr(str_shuffle($caracteres), 0, 5); 
    } 
}

?>