<?php

namespace App\Controllers;

use App\Models\Ingreso;

class IngresoController{
    public function traerTodos($request, $response, $args) {
        $data = Ingreso::all();
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public static function crear($id, $nombre, $tipo) {
        date_default_timezone_set("America/Argentina/Buenos_Aires");
        
        $ingreso = new Ingreso;
        $ingreso->usuario = $id;
        $ingreso->nombre = $nombre;
        $ingreso->tipo = $tipo;
        $ingreso->fecha = date("Y-m-d H:i:s");

        $data = $ingreso->save();
    }
}

?>