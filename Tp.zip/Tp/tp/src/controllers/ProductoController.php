<?php

namespace App\Controllers;

use App\Models\Producto;

class ProductoController{
    public function traer($request, $response, $args) {
        $data = Producto::find($args['id']);
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function traerTodos($request, $response, $args) {
        $data = Producto::all();
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function crear($request, $response, $args) {
        if (!(isset($request->getParsedBody()['nombre']) && 
            isset($request->getParsedBody()['precio']) &&
            isset($request->getParsedBody()['tipo']))) {
            $data = array("Error" => "Faltan parametros");
            $response->getBody()->write(json_encode($data));
    
            return $response->withStatus(400);
        }

        if ($request->getParsedBody()['tipo'] != "cocina" &&
            $request->getParsedBody()['tipo'] != "bar" &&
            $request->getParsedBody()['tipo'] != "cerveza") {
            $data = array("Error" => "Tipo inexistente");
            $response->getBody()->write(json_encode($data));
    
            return $response->withStatus(400);
        }

        $producto = new Producto;
        $producto->nombre = $request->getParsedBody()['nombre'];
        $producto->precio = $request->getParsedBody()['precio'];
        $producto->tipo = $request->getParsedBody()['tipo'];

        if (Producto::where("nombre", $producto->nombre)->first()) {
            $data = array("Error" => "Ya se registro ese producto");
            $response->getBody()->write(json_encode($data));
    
            return $response->withStatus(400);
        }

        $data = $producto->save();

        $response->getBody()->write(json_encode($data));

        return $response->withStatus(200);
    }
}

?>