<?php

namespace App\Controllers;

use App\Models\Cuenta;
use App\Models\Pedido;

class CuentaController{
    public function traer($request, $response, $args) { 
        $data = Cuenta::find($args['id']);
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function traerTodos($request, $response, $args) {
        $data = Cuenta::all();
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public static function facturar($codigo) {
        date_default_timezone_set("America/Argentina/Buenos_Aires");

        $pedidos = Pedido::where("mesa", $codigo)->get();
        $monto = 0;

        foreach ($pedidos as $pedido) {
            if ($pedido->estado != "cancelado" && $pedido->estado != "cobrado") {
                $monto = $monto + $pedido->total;
                $pedido->estado = "cobrado";
                $pedido->save();
            }
        }

        if ($monto != 0) {
            $cuenta = new Cuenta;
            $cuenta->monto = $monto;
            $cuenta->mesa = $codigo;
            $cuenta->fecha = date("Y-m-d H:i:s");
            $cuenta->save();
        }


        return $monto;
    }
}

?>