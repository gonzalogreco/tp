<?php

namespace App\Controllers;

use App\Models\Mozo;

class MozoController{
    public function get($request, $response, $args) {
        $data = Mozo::find($args['id']);
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }
}

?>