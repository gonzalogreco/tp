<?php

namespace App\Controllers;

use App\Models\Usuario;
use Token\Token;
use App\Controllers\IngresoController;

class UsuarioController{
    public function get($request, $response, $args) {
        $data = Usuario::find($args['id']);
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function crear($request, $response, $args) {
        if (!(isset($request->getParsedBody()['nombre']) && 
            isset($request->getParsedBody()['mail']) &&
            isset($request->getParsedBody()['password']) && 
            isset($request->getParsedBody()['tipo']))) {
            $data = array("Error" => "Faltan parametros");
            $response->getBody()->write(json_encode($data));
    
            return $response->withStatus(400);
        }

        if ($request->getParsedBody()['tipo'] != "bartender" &&
            $request->getParsedBody()['tipo'] != "cervecero" &&
            $request->getParsedBody()['tipo'] != "mozo" &&
            $request->getParsedBody()['tipo'] != "socio") {
            $data = array("Error" => "Tipo inexistente");
            $response->getBody()->write(json_encode($data));

            return $response->withStatus(400);
        }

        $usuario = new Usuario;
        $usuario->nombre = $request->getParsedBody()['nombre'];
        $usuario->mail = $request->getParsedBody()['mail'];
        $usuario->password = $request->getParsedBody()['password'];
        $usuario->tipo = $request->getParsedBody()['tipo'];

        if (Usuario::where("mail", $usuario->mail)->first()) {
            $data = array("Error" => "Ya se registro ese mail");
            $response->getBody()->write(json_encode($data));
    
            return $response->withStatus(400);
        }

        $data = $usuario->save();

        $response->getBody()->write(json_encode($data));

        return $response->withStatus(200);
    }

    public function login($request, $response, $args) {
        $mail = $request->getParsedBody()['mail'];
        $password = $request->getParsedBody()['password'];

        $usuario = Usuario::where("mail", $mail)->first();

        if (isset($usuario) && $usuario->password == $password) {
            IngresoController::crear($usuario->id, $usuario->nombre, $usuario->tipo);
            $token = Token::CrearToken($usuario->id, $usuario->nombre, $usuario->tipo);
            $response->getBody()->write(json_encode($token));

            return $response->withStatus(200);
        }

        $data = array("Error" => "No se pudo logear");
        $response->getBody()->write(json_encode($data));

        return $response->withStatus(401);
    }
}

?>