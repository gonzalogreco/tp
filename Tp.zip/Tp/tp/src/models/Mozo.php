<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Mozo extends Model{
    public $timestamps = false;
}

?>