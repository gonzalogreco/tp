<?php

namespace App\Middlewares;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Slim\Psr7\Response;
use Token\Token;

class AuthMiddleware{
    public function __invoke(Request $request, RequestHandler $handler){
        $jwt = Token::ValidarToken();
        if (!$jwt) {
            $response = new Response();

            $data = array("estado" => "Token no autorizado");

            $response->getBody()->write(json_encode($data));

            return $response->withStatus(401);
        } else {
            $response = $handler->handle($request);
            $existingContent = (string) $response->getBody();
        
            $response = new Response();
            $response->getBody()->write($existingContent);
        
            return $response;
        }  
    }
}

?>