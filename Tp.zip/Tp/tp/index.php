<?php
require __DIR__.'/vendor/autoload.php';

use \Firebase\JWT\JWT;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;
use Slim\Routing\MesaCollectorProxy;
use App\Controllers\UsuarioController;
use App\Controllers\MozoController;
use App\Controllers\SocioController;
use App\Controllers\PedidoController;
use App\Controllers\ProductoController;
use App\Controllers\IngresoController;
use App\Controllers\MesaController;
use App\Controllers\EncuestaController;
use App\Controllers\CuentaController;
use Config\Database;
use App\Middlewares\JsonMiddleware;
use App\Middlewares\AuthMiddleware;
use App\Middlewares\MozoMiddleware;
use App\Middlewares\SocioMiddleware;
use Slim\Routing\RouteCollectorProxy;

$app = AppFactory::create();
$app->setBasePath('/Tp/tp');
new Database;

$app->get('/ping', function ($request, $response, array $args) {
    $response->getBody()->write("Pong!");
    return $response->withStatus(200);
});

//USUARIOS Y AUTENTICACION
$app->post('/users', UsuarioController::class.":crear");
$app->post('/login', UsuarioController::class.":login");

//LOGS
$app->get('/ingresos', IngresoController::class.":traerTodos")->add(new SocioMiddleware);

//ENCUESTA
$app->post('/encuesta/{codigo}[/]', EncuestaController::class.":puntuar");

//PRODUCTO
$app->group('/producto', function (RouteCollectorProxy $group) {
    $group->get('[/]', ProductoController::class.":traerTodos");

    $group->get('/{id}[/]', ProductoController::class.":traer");

    $group->post('[/]', ProductoController::class.":crear");
})->add(new SocioMiddleware);

//MESA
$app->group('/mesa', function (RouteCollectorProxy $group) {
    $group->get('[/]', MesaController::class.":traerTodos");

    $group->get('/{codigo}[/]', MesaController::class.":traer");

    $group->post('[/]', MesaController::class.":crear")->add(new SocioMiddleware);

    $group->post('/estado/{codigo}[/]', MesaController::class.":cambiarEstado");

    $group->post('/cerrar/{codigo}[/]', MesaController::class.":cerrar")->add(new SocioMiddleware);
})->add(new MozoMiddleware);

//PEDIDO
$app->group('/pedido', function (RouteCollectorProxy $group) {
    $group->get('[/]', PedidoController::class.":traerTodos")->add(new MozoMiddleware);

    $group->get('/pendientes[/]', PedidoController::class.":traerPendientes")->add(new AuthMiddleware);

    $group->get('/{codigo}[/]', PedidoController::class.":traer")->add(new MozoMiddleware);

    $group->post('[/]', PedidoController::class.":crear")->add(new MozoMiddleware);

    $group->post('/preparacion/{codigo}[/]', PedidoController::class.":cambiarEstadoEnPreparacion")->add(new AuthMiddleware);

    $group->post('/listo/{codigo}[/]', PedidoController::class.":cambiarEstadoListo")->add(new AuthMiddleware);

    $group->post('/cancelar/{codigo}[/]', PedidoController::class.":cancelar")->add(new MozoMiddleware);

    $group->get('/tiempo/{codigo}/{mesa}[/]', PedidoController::class.":tiempoRestante");
});

//CUENTA
$app->group('/cuenta', function (RouteCollectorProxy $group) {
    $group->get('[/]', ProductoController::class.":traerTodos");

    $group->get('/{id}[/]', ProductoController::class.":traer");
})->add(new SocioMiddleware);

$app->add(new JsonMiddleware);

$app->run();

?>