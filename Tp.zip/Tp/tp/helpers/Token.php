<?php

namespace Token;

use \Firebase\JWT\JWT;

class Token {

    private static $key = "tp";
    private static $encriptacion = ['HS256'];

    static function ValidarToken(){
        try {
            $token = isset($_SERVER['HTTP_TOKEN']) ? $_SERVER['HTTP_TOKEN'] : null;
            $decode = JWT::decode($token, self::$key, self::$encriptacion);
            return $decode;
        } catch (\Throwable $th) {
            return false;
        }
    }

    static function CrearToken($id, $nombre, $tipo){
        $payload = array(
            "id" => $id,
            "nombre" => $nombre,
            "tipo" => $tipo,
        );

        $token = JWT::encode($payload, self::$key);

        return $token;
    }

    static function DevolverId(){
        $decode = JWT::decode($_SERVER['HTTP_TOKEN'], self::$key, self::$encriptacion);
        return $decode->id;
    }
}

?>